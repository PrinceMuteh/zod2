/*
Template Name: Dason - Admin & Dashboard Template
Author: Themesdesign
Website: https://themesdesign.in/
Contact: themesdesign.in@gmail.com
File: lightbox Js File
*/

// GLightbox Popup

var lightbox = GLightbox({
    selector: '.image-popup',
    title: false,
});


// GLightbox Popup

var lightboxDesc = GLightbox({
    selector: '.image-popup-desc',
});

// GLightbox Popup

var lightboxvideo = GLightbox({
    selector: '.image-popup-video-map',
    title: false,
});
