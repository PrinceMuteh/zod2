/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
/*!************************************************!*\
  !*** ./resources/js/pages/task-kanban.init.js ***!
  \************************************************/
/*
Template Name: Dason - Admin & Dashboard Template
Author: Themesdesign
Website: https://themesdesign.in/
Contact: themesdesign.in@gmail.com
File: task kanban Init Js File
*/
dragula([document.getElementById("upcoming-task"), document.getElementById("inprogress-task"), document.getElementById("complete-task")]);
/******/ })()
;